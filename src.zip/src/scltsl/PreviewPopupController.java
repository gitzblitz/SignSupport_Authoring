/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package scltsl;

import java.io.File;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.Timer;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Masilo
 */
public class PreviewPopupController implements Initializable {

    Stage dialogStage;
    boolean isPicture = false;
    Lesson lesson;
    File currentResourceFile;
    ImageView imageView;
    MediaView mediaView;
    Timer lessonTimer;
    boolean pictureDurationDone = false;
    boolean lessonDone = false;
    
    @FXML
    public AnchorPane playerPane;
    public Button playOrPause;
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        /*dialogStage.setOnHidden(new EventHandler<WindowEvent>() {

                @Override
                public void handle(WindowEvent t) {
                    //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                    dialogStage.close();
                }
            });
            */
        
       lessonTimer = new Timer();
        
    }
    
    public void close(){
        lessonTimer.cancel();
        
    }
    
    /**
     * Sets the stage of this dialog.
     * @param dialogStage
     */
    public void setDialogStage(Stage dialogStage) {
        this.dialogStage = dialogStage;
        
        //this.dialogStage.getScene().getRoot().getChildrenUnmodifiable().add(mediaView);
    }
    
    @FXML
    public void pauseOrPlay(ActionEvent event){
        //if (lesson.)
        if (mediaView.getMediaPlayer().getStatus() == MediaPlayer.Status.PLAYING){
            mediaView.getMediaPlayer().pause();
        }
        else {
            mediaView.getMediaPlayer().play();
        }
    }
    
    @FXML
    public void stop(ActionEvent event){
        mediaView.getMediaPlayer().stop();
    }
    
    /**
     * Set the lesson to preview
     * @param l the lesson to preview
     */
    public void setLesson(Lesson l){
        
    }
    
    /**
     * view the next resource
     */
    public void next(){
    }
    
}
