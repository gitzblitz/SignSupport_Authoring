/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package scltsl;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.scene.image.Image;
import javafx.scene.input.Clipboard;
import javafx.scene.input.ClipboardContent;
import javafx.scene.input.DragEvent;
import javafx.scene.input.Dragboard;
import javafx.scene.input.MouseEvent;
import javafx.scene.input.TransferMode;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.paint.Paint;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;
import javax.swing.JOptionPane;

/**
 *
 * @author Muchenja Namumba, Masilo Mapaila and Chad Petersen
 */
public class LessonController extends AnchorPane implements Initializable {

    /**
     * *****Global Constants**********
     */
    private final int resourceXDistance = 110;
    private final int resourceYDistance = 110;
    private final int resourceWidth = 80;
    private final int resourceHeight = 80;
    private final int dropRegionLayoutX = 165;
    private final int dropRegionLayoutY = 80;
    private final int stepButtonLayoutX = 59;
    private final int stepButtonLayoutY = 323;
    private final ArrayList<String> imageExtensions = new ArrayList<String>() {
        {
            add("*.png");
            add("*.gif");
            add("*.jpg");
            add("*.jpeg");
            add("*.jpe");
            add("*.jfif");
            add("*.bmp");
        }
    };
    private final ArrayList<String> videoExtensions = new ArrayList<String>() {
        {
            add("*.mp4");
            add("*.avi");
            add("*.wmv");
            add("*.mpg");
            add("*.mpg2");
            add("*.mpeg");
            add("*.3gp");
            add("*.3gp2");
            add("*.3gpp");
            add("*.3gpp2");
        }
    };
    /**
     * *****Global Variables**********
     */
    static boolean trueOrFalse = false;
    private boolean creatingLesson = false;
    private int currentLessonIndex;
    final ImageView saveImage = new ImageView(new File("icons/save_1.png").toURI().toString());
    final ImageView playImage = new ImageView(new File("icons/play-icon.png").toURI().toString());
    
    
    private Lesson lesson;
    public ArrayList<Rectangle> stepDropRegions;
    public ArrayList<Label> stepLabels;
    public ArrayList<String> videoNames;
    public ArrayList<String> pictureNames;
    public ArrayList<Lesson> listOfLessons;
    public ArrayList<String> lessonNames;
    PreviewPopupController controller;
    MessagePopupController messageController;
    
    
    // default values
    private int numberOfSteps = 1;
    private int picCount = 0;
    private int vidCount = 0;
    private int lessonCount = 0;
    Rectangle firstStepDropRegion;
    
    @FXML
    private Label status;
    public Label firstStepLabel;
    public Button button;
    public Button newStep;
    public Button saveButton;
    public Button createLessonButton;
    public Button playButton;
    public AnchorPane lessonPane;
    public AnchorPane picturePane;
    public ScrollPane lessonScroll;
    public ListView videoList;
    public ComboBox lessonList;
    public ComboBox lessonTypeList;
    public Rectangle ldDropRegion;
    public Rectangle tdDropRegion;
    public Rectangle s1DropRegion;
    public TextField l_title;
    public TextField l_type;
    private SCLTSL application;

    public void setApp(SCLTSL application) {
        this.application = application;
        
        getListOfResources();
        refreshResourceList();
        refreshLessonList();

        // set lesson type list
        ObservableList<String> types = FXCollections.observableArrayList();
        types.add("O");
        types.add("S");
        types.add("E");
        lessonTypeList.setItems(types);

        // set button icons
        /*saveImage.setFitHeight(32);
        playImage.setFitHeight(32);
        saveImage.setFitWidth(32);
        playImage.setFitWidth(32);
        saveButton.setGraphic(saveImage);
        playButton.setGraphic(playButton);*/
        

        stepDropRegions = new ArrayList<>(10);
        stepLabels = new ArrayList<>(10);

        firstStepDropRegion = s1DropRegion;

        /* set drag-and-drop events */
        ldDropRegion.setOnDragEntered(new EventHandler<DragEvent>() {
            @Override
            public void handle(DragEvent event) {
                handleOnDragEntered(event, ldDropRegion);
            }
        });
        ldDropRegion.setOnDragExited(new EventHandler<DragEvent>() {
            @Override
            public void handle(DragEvent event) {
                handleOnDragExited(event, ldDropRegion);
            }
        });
        tdDropRegion.setOnDragEntered(new EventHandler<DragEvent>() {
            @Override
            public void handle(DragEvent event) {
                handleOnDragEntered(event, tdDropRegion);
            }
        });
        tdDropRegion.setOnDragExited(new EventHandler<DragEvent>() {
            @Override
            public void handle(DragEvent event) {
                handleOnDragExited(event, tdDropRegion);
            }
        });
        s1DropRegion.setOnDragEntered(new EventHandler<DragEvent>() {
            @Override
            public void handle(DragEvent event) {
                handleOnDragEntered(event, s1DropRegion);
            }
        });
        s1DropRegion.setOnDragExited(new EventHandler<DragEvent>() {
            @Override
            public void handle(DragEvent event) {
                handleOnDragExited(event, s1DropRegion);
            }
        });
        
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
    }
    
    /*public void selectLesson(ActionEvent event) {
        
        if (lessonList.getSelectionModel().isSelected(0)) {
            newLesson();
        } else {
            // load unit data
       
            try{
            lesson = application.lessonHandler.getLesson((String) lessonList.getSelectionModel().getSelectedItem());
            
            for (int i = 0; i < lesson.getSteps().size(); i++) {

                String stepName = lesson.getSteps().get(i).getResource(i).getName();

                final Text s = new Text(stepName);
                s.setWrappingWidth(resourceWidth);

                s.setOnDragOver(new EventHandler<DragEvent>() {
                    @Override
                    public void handle(DragEvent t) {
                        handleOnDragOver(t);
                    }
                });
                s.setOnDragEntered(new EventHandler<DragEvent>() {
                    @Override
                    public void handle(DragEvent t) {
                        handleOnDragEntered(t, s);
                    }
                });
                s.setOnDragExited(new EventHandler<DragEvent>() {
                    @Override
                    public void handle(DragEvent t) {
                        handleOnDragExited(t, s);
                    }
                });
                s.setOnDragDropped(new EventHandler<DragEvent>() {
                    @Override
                    public void handle(DragEvent t) {
                        handleOnDragDropped(t);
                    }
                });

              /*  String lessonType = application.lessonHandler.getLessonList().
                        get(application.lessonHandler.searchForLesson(currentUnit.getLessonPlaceHolders().get(i))).getType();
                if (lessonType.toLowerCase().charAt(0) == 'o') {
                    s.setLayoutX(typeODropRegion.getLayoutX());
                    s.setLayoutY(typeODropRegion.getLayoutY());
                    nextLesson(typeODropRegion);
                } else if (lessonType.toLowerCase().charAt(0) == 's') {
                    s.setLayoutX(typeSDropRegion.getLayoutX());
                    s.setLayoutY(typeSDropRegion.getLayoutY());
                    nextLesson(typeSDropRegion);
                } else if (lessonType.toLowerCase().charAt(0) == 'e') {
                    s.setLayoutX(typeEDropRegion.getLayoutX());
                    s.setLayoutY(typeEDropRegion.getLayoutY());
                    nextLesson(typeEDropRegion);
                }*/
/*
                lessonPane.getChildren().add((Text) s);
            }
        }catch(Exception e){}
        }
    }*/
    
    public void selectLesson(ActionEvent event) {

        // clear workspace
        clearWorkSpace();

        if (lessonList.getSelectionModel().isSelected(0)) {
            currentLessonIndex = 0;
            newLesson(event);
        } else {
            
            try{
                lesson = application.lessonHandler.getLesson((String) lessonList.getSelectionModel().getSelectedItem());
                if(lesson.getType().toLowerCase().charAt(0) == 'o')
                    lessonTypeList.getSelectionModel().select(0);
                else if(lesson.getType().toLowerCase().charAt(0) == 's')
                    lessonTypeList.getSelectionModel().select(1);
                else if(lesson.getType().toLowerCase().charAt(0) == 'e')
                    lessonTypeList.getSelectionModel().select(2);
                currentLessonIndex = lessonList.getSelectionModel().getSelectedIndex();
                int index = 0;
                for (int i = 0; i < lesson.getSteps().size(); i++) {
                    if(i > 2){
                        newStep(event);
                    }
                    for(int j = 0; j < lesson.getSteps().get(i).getResources().size(); j++){
                            String resName = lesson.getSteps().get(i).getResources().get(j).getName();
                            System.out.println(numberOfSteps + " " + lesson.getSteps().size() + " "+stepDropRegions.size());
                            Rectangle rec = new Rectangle();
                            if(stepDropRegions.size() > 0 && numberOfSteps > 1 && i > 2)
                                rec = stepDropRegions.get(numberOfSteps - 1);
                            
                           /* if (lesson.getSteps().get(i).getResources().get(j).getType().equals(Resource.ResourceType.IMAGE)){
                                final ImageView s = new ImageView(new File(SCLTSL.imageDirPath + lesson.getSteps().get(i).getResources().get(j).getName()).toURI().toString());
                                s.setId((i - 1) + "_" + lesson.getSteps().get(i).getResourceIndex(lesson.getSteps().get(i).getResources().get(j)));
                                s.setFitHeight(resourceHeight);
                                s.setFitWidth(resourceWidth);
                                //s.setLayoutX(ldDropRegion.getLayoutX());
                               // s.setLayoutY(ldDropRegion.getLayoutY());
                                
                                s.setOnDragDetected(new EventHandler<MouseEvent>() {
                                    @Override
                                    public void handle(MouseEvent t) {
                                        handleOnDragDetected(t);
                                    }
                                });
                                s.setOnDragOver(new EventHandler<DragEvent>() {
                                    @Override
                                    public void handle(DragEvent t) {
                                        handleOnDragOver(t);
                                    }
                                });
                                s.setOnDragEntered(new EventHandler<DragEvent>() {
                                    @Override
                                    public void handle(DragEvent t) {
                                        handleOnDragEntered(t, s);
                                    }
                                });
                                s.setOnDragExited(new EventHandler<DragEvent>() {
                                    @Override
                                    public void handle(DragEvent t) {
                                        handleOnDragExited(t, s);
                                    }
                                });
                                s.setOnDragDropped(new EventHandler<DragEvent>() {
                                    @Override
                                    public void handle(DragEvent t) {
                                        handleOnDragDropped(t);
                                    }
                                });

                                lessonPane.getChildren().add((ImageView) s);

                            }
                            else{*/
                                final Text s = new Text(resName);
                                s.setWrappingWidth(resourceWidth);
                               // s.setLayoutX(ldDropRegion.getLayoutX());
                                //s.setLayoutY(ldDropRegion.getLayoutY());
                                //s.setLayoutX(rec.getLayoutX());
                                //s.setLayoutY(rec.getLayoutY());

                                s.setOnDragDetected(new EventHandler<MouseEvent>() {
                                    @Override
                                    public void handle(MouseEvent t) {
                                        handleOnDragDetected(t);
                                    }
                                });
                                s.setOnDragOver(new EventHandler<DragEvent>() {
                                    @Override
                                    public void handle(DragEvent t) {
                                        handleOnDragOver(t);
                                    }
                                });
                                s.setOnDragEntered(new EventHandler<DragEvent>() {
                                    @Override
                                    public void handle(DragEvent t) {
                                        handleOnDragEntered(t, s);
                                    }
                                });
                                s.setOnDragExited(new EventHandler<DragEvent>() {
                                    @Override
                                    public void handle(DragEvent t) {
                                        handleOnDragExited(t, s);
                                    }
                                });
                                s.setOnDragDropped(new EventHandler<DragEvent>() {
                                    @Override
                                    public void handle(DragEvent t) {
                                        handleOnDragDropped(t);
                                    }
                                });

                                s.setId(i + "_" + (lesson.getlastResourceIndex(i) + 1));
                            //}
                            
                            if(i == 0){
                                s.setLayoutX(ldDropRegion.getLayoutX());
                                s.setLayoutY(ldDropRegion.getLayoutY());
                                nextResource(ldDropRegion);
                            }
                            else if(i == 1){
                                s.setLayoutX(tdDropRegion.getLayoutX());
                                s.setLayoutY(tdDropRegion.getLayoutY());
                                nextResource(tdDropRegion);
                            }
                            else if(i == 2){
                                s.setLayoutX(s1DropRegion.getLayoutX());
                                s.setLayoutY(s1DropRegion.getLayoutY());
                                nextResource(s1DropRegion);
                            }
                            else if(stepDropRegions.size() > 0 && numberOfSteps > 1 && i > 2){
                                s.setLayoutX(rec.getLayoutX());
                                s.setLayoutY(rec.getLayoutY());
                                nextResource(rec);
                            }
                            lessonPane.getChildren().add((Text) s);
                           
                    }
                        
                }
              /*  for (Step step : lesson.getSteps()) {

                    if (step.getNumber() > 4){
                        newStep(event);
                    }

                    for (Resource resource : step.getResources()) {
                        if (step.getNumber() == 1) {

                            index = 1;

                            if (resource.getType() == Resource.ResourceType.IMAGE) {

                                final ImageView s = new ImageView(new File(SCLTSL.imageDirPath + resource.getName()).toURI().toString());
                                s.setId((index - 1) + "_" + step.getResourceIndex(resource));
                                s.setFitHeight(resourceHeight);
                                s.setFitWidth(resourceWidth);
                                s.setLayoutX(ldDropRegion.getLayoutX());
                                s.setLayoutY(ldDropRegion.getLayoutY());

                                s.setOnDragDetected(new EventHandler<MouseEvent>() {
                                    @Override
                                    public void handle(MouseEvent t) {
                                        handleOnDragDetected(t);
                                    }
                                });
                                s.setOnDragOver(new EventHandler<DragEvent>() {
                                    @Override
                                    public void handle(DragEvent t) {
                                        handleOnDragOver(t);
                                    }
                                });
                                s.setOnDragEntered(new EventHandler<DragEvent>() {
                                    @Override
                                    public void handle(DragEvent t) {
                                        handleOnDragEntered(t, s);
                                    }
                                });
                                s.setOnDragExited(new EventHandler<DragEvent>() {
                                    @Override
                                    public void handle(DragEvent t) {
                                        handleOnDragExited(t, s);
                                    }
                                });
                                s.setOnDragDropped(new EventHandler<DragEvent>() {
                                    @Override
                                    public void handle(DragEvent t) {
                                        handleOnDragDropped(t);
                                    }
                                });

                                lessonPane.getChildren().add((ImageView) s);
                                nextResource(ldDropRegion);


                            } else {

                                final Text s = new Text(resource.getName());
                                s.setWrappingWidth(resourceWidth);
                                s.setLayoutX(ldDropRegion.getLayoutX());
                                s.setLayoutY(ldDropRegion.getLayoutY());

                                s.setOnDragDetected(new EventHandler<MouseEvent>() {
                                    @Override
                                    public void handle(MouseEvent t) {
                                        handleOnDragDetected(t);
                                    }
                                });
                                s.setOnDragOver(new EventHandler<DragEvent>() {
                                    @Override
                                    public void handle(DragEvent t) {
                                        handleOnDragOver(t);
                                    }
                                });
                                s.setOnDragEntered(new EventHandler<DragEvent>() {
                                    @Override
                                    public void handle(DragEvent t) {
                                        handleOnDragEntered(t, s);
                                    }
                                });
                                s.setOnDragExited(new EventHandler<DragEvent>() {
                                    @Override
                                    public void handle(DragEvent t) {
                                        handleOnDragExited(t, s);
                                    }
                                });
                                s.setOnDragDropped(new EventHandler<DragEvent>() {
                                    @Override
                                    public void handle(DragEvent t) {
                                        handleOnDragDropped(t);
                                    }
                                });

                                s.setId(index + "_" + (lesson.getlastResourceIndex(index) + 1));
                                lessonPane.getChildren().add((Text) s);
                                nextResource(ldDropRegion);
                            }
                        } else if (step.getNumber() == 2) {

                            index = 2;

                            if (resource.getType() == Resource.ResourceType.IMAGE) {

                                final ImageView s = new ImageView(new File(SCLTSL.imageDirPath + resource.getName()).toURI().toString());
                                s.setId((index - 1) + "_" + step.getResourceIndex(resource));
                                s.setFitHeight(resourceHeight);
                                s.setFitWidth(resourceWidth);
                                s.setLayoutX(tdDropRegion.getLayoutX());
                                s.setLayoutY(tdDropRegion.getLayoutY());

                                s.setOnDragDetected(new EventHandler<MouseEvent>() {
                                    @Override
                                    public void handle(MouseEvent t) {
                                        handleOnDragDetected(t);
                                    }
                                });
                                s.setOnDragOver(new EventHandler<DragEvent>() {
                                    @Override
                                    public void handle(DragEvent t) {
                                        handleOnDragOver(t);
                                    }
                                });
                                s.setOnDragEntered(new EventHandler<DragEvent>() {
                                    @Override
                                    public void handle(DragEvent t) {
                                        handleOnDragEntered(t, s);
                                    }
                                });
                                s.setOnDragExited(new EventHandler<DragEvent>() {
                                    @Override
                                    public void handle(DragEvent t) {
                                        handleOnDragExited(t, s);
                                    }
                                });
                                s.setOnDragDropped(new EventHandler<DragEvent>() {
                                    @Override
                                    public void handle(DragEvent t) {
                                        handleOnDragDropped(t);
                                    }
                                });

                                lessonPane.getChildren().add((ImageView) s);
                                nextResource(tdDropRegion);

                            } else {

                                index = 2;

                                final Text s = new Text(resource.getName());
                                s.setWrappingWidth(resourceWidth);
                                s.setLayoutX(tdDropRegion.getLayoutX());
                                s.setLayoutY(tdDropRegion.getLayoutY());

                                s.setOnDragDetected(new EventHandler<MouseEvent>() {
                                    @Override
                                    public void handle(MouseEvent t) {
                                        handleOnDragDetected(t);
                                    }
                                });
                                s.setOnDragOver(new EventHandler<DragEvent>() {
                                    @Override
                                    public void handle(DragEvent t) {
                                        handleOnDragOver(t);
                                    }
                                });
                                s.setOnDragEntered(new EventHandler<DragEvent>() {
                                    @Override
                                    public void handle(DragEvent t) {
                                        handleOnDragEntered(t, s);
                                    }
                                });
                                s.setOnDragExited(new EventHandler<DragEvent>() {
                                    @Override
                                    public void handle(DragEvent t) {
                                        handleOnDragExited(t, s);
                                    }
                                });
                                s.setOnDragDropped(new EventHandler<DragEvent>() {
                                    @Override
                                    public void handle(DragEvent t) {
                                        handleOnDragDropped(t);
                                    }
                                });

                                s.setId(index + "_" + (lesson.getlastResourceIndex(index) + 1));
                                lessonPane.getChildren().add((Text) s);
                                nextResource(tdDropRegion);
                            }
                        } else if (step.getNumber() == 3) {
                            index = 3;
                            if (resource.getType() == Resource.ResourceType.IMAGE) {

                                final ImageView s = new ImageView(new File(SCLTSL.imageDirPath + resource.getName()).toURI().toString());
                                s.setId((index - 1) + "_" + step.getResourceIndex(resource));
                                s.setFitHeight(resourceHeight);
                                s.setFitWidth(resourceWidth);
                                s.setLayoutX(s1DropRegion.getLayoutX());
                                s.setLayoutY(s1DropRegion.getLayoutY());

                                s.setOnDragDetected(new EventHandler<MouseEvent>() {
                                    @Override
                                    public void handle(MouseEvent t) {
                                        handleOnDragDetected(t);
                                    }
                                });
                                s.setOnDragOver(new EventHandler<DragEvent>() {
                                    @Override
                                    public void handle(DragEvent t) {
                                        handleOnDragOver(t);
                                    }
                                });
                                s.setOnDragEntered(new EventHandler<DragEvent>() {
                                    @Override
                                    public void handle(DragEvent t) {
                                        handleOnDragEntered(t, s);
                                    }
                                });
                                s.setOnDragExited(new EventHandler<DragEvent>() {
                                    @Override
                                    public void handle(DragEvent t) {
                                        handleOnDragExited(t, s);
                                    }
                                });
                                s.setOnDragDropped(new EventHandler<DragEvent>() {
                                    @Override
                                    public void handle(DragEvent t) {
                                        handleOnDragDropped(t);
                                    }
                                });

                                lessonPane.getChildren().add((ImageView) s);
                                nextResource(s1DropRegion);

                            } else {

                                final Text s = new Text(resource.getName());
                                s.setWrappingWidth(resourceWidth);
                                s.setLayoutX(s1DropRegion.getLayoutX());
                                s.setLayoutY(s1DropRegion.getLayoutY());

                                s.setOnDragDetected(new EventHandler<MouseEvent>() {
                                    @Override
                                    public void handle(MouseEvent t) {
                                        handleOnDragDetected(t);
                                    }
                                });
                                s.setOnDragOver(new EventHandler<DragEvent>() {
                                    @Override
                                    public void handle(DragEvent t) {
                                        handleOnDragOver(t);
                                    }
                                });
                                s.setOnDragEntered(new EventHandler<DragEvent>() {
                                    @Override
                                    public void handle(DragEvent t) {
                                        handleOnDragEntered(t, s);
                                    }
                                });
                                s.setOnDragExited(new EventHandler<DragEvent>() {
                                    @Override
                                    public void handle(DragEvent t) {
                                        handleOnDragExited(t, s);
                                    }
                                });
                                s.setOnDragDropped(new EventHandler<DragEvent>() {
                                    @Override
                                    public void handle(DragEvent t) {
                                        handleOnDragDropped(t);
                                    }
                                });

                                s.setId(index + "_" + (lesson.getlastResourceIndex(index) + 1));
                                lessonPane.getChildren().add((Text) s);
                                nextResource(s1DropRegion);

                            }
                        } else {

                            //newStep(event);
                            index = stepDropRegions.size();
                            Rectangle rec = stepDropRegions.get(numberOfSteps - 1);

                            if (resource.getType() == Resource.ResourceType.IMAGE) {

                                final ImageView s = new ImageView(new File(SCLTSL.imageDirPath + resource.getName()).toURI().toString());
                                s.setId((index - 1) + "_" + step.getResourceIndex(resource));
                                s.setFitHeight(resourceHeight);
                                s.setFitWidth(resourceWidth);
                                s.setLayoutX(rec.getLayoutX());
                                s.setLayoutY(rec.getLayoutY());

                                s.setOnDragDetected(new EventHandler<MouseEvent>() {
                                    @Override
                                    public void handle(MouseEvent t) {
                                        handleOnDragDetected(t);
                                    }
                                });
                                s.setOnDragOver(new EventHandler<DragEvent>() {
                                    @Override
                                    public void handle(DragEvent t) {
                                        handleOnDragOver(t);
                                    }
                                });
                                s.setOnDragEntered(new EventHandler<DragEvent>() {
                                    @Override
                                    public void handle(DragEvent t) {
                                        handleOnDragEntered(t, s);
                                    }
                                });
                                s.setOnDragExited(new EventHandler<DragEvent>() {
                                    @Override
                                    public void handle(DragEvent t) {
                                        handleOnDragExited(t, s);
                                    }
                                });
                                s.setOnDragDropped(new EventHandler<DragEvent>() {
                                    @Override
                                    public void handle(DragEvent t) {
                                        handleOnDragDropped(t);
                                    }
                                });

                                lessonPane.getChildren().add((ImageView) s);
                                nextResource(rec);

                            } else {

                                final Text s = new Text(resource.getName());
                                s.setWrappingWidth(resourceWidth);
                                s.setLayoutX(rec.getLayoutX());
                                s.setLayoutY(rec.getLayoutY());

                                s.setOnDragDetected(new EventHandler<MouseEvent>() {
                                    @Override
                                    public void handle(MouseEvent t) {
                                        handleOnDragDetected(t);
                                    }
                                });
                                s.setOnDragOver(new EventHandler<DragEvent>() {
                                    @Override
                                    public void handle(DragEvent t) {
                                        handleOnDragOver(t);
                                    }
                                });
                                s.setOnDragEntered(new EventHandler<DragEvent>() {
                                    @Override
                                    public void handle(DragEvent t) {
                                        handleOnDragEntered(t, s);
                                    }
                                });
                                s.setOnDragExited(new EventHandler<DragEvent>() {
                                    @Override
                                    public void handle(DragEvent t) {
                                        handleOnDragExited(t, s);
                                    }
                                });
                                s.setOnDragDropped(new EventHandler<DragEvent>() {
                                    @Override
                                    public void handle(DragEvent t) {
                                        handleOnDragDropped(t);
                                    }
                                });

                                s.setId(index + "_" + (lesson.getlastResourceIndex(index) + 1));
                                lessonPane.getChildren().add((Text) s);
                                nextResource(rec);
                            }
                        }
                    }
                }*/
            }catch(Exception e){}
        }
    }
    
     private void clearWorkSpace() {
        // remove drop regions
        for (Object obj : stepDropRegions) {
            lessonPane.getChildren().remove(obj);
        }
        stepDropRegions.clear();

        // remove step labels
        for (Object obj : stepLabels) {
            lessonPane.getChildren().remove(obj);
        }
        stepLabels.clear();

        // update scroll bars
        lessonPane.setPrefHeight(428.0);
        lessonPane.setPrefWidth(667.0);

        // reposition widgets
        l_title.setText("");
        //l_type.setText("");
        ldDropRegion.setLayoutX(dropRegionLayoutX);
        ldDropRegion.setLayoutY(23.0);
        tdDropRegion.setLayoutX(dropRegionLayoutX);
        tdDropRegion.setLayoutY(133.0);
        s1DropRegion.setLayoutX(dropRegionLayoutX);
        s1DropRegion.setLayoutY(243.0);
        newStep.setLayoutX(stepButtonLayoutX);
        newStep.setLayoutY(stepButtonLayoutY);
    }
    
    
    public void selectLessonType(ActionEvent event) {
        lesson.setType(lessonTypeList.getSelectionModel().getSelectedItem().toString());
    }
    
    public void createCourse(ActionEvent event) {
        application.createCourseOrUnit();
    }
    
    @FXML
    public void createCourse(){
        openCourse("");
    }
    
    @FXML
    public void openCourse(String courseID) {
        if (courseID.isEmpty()) {
            application.createCourseOrUnit();
        } else {
           Course course = application.courseHandler.getCourseList().get(application.courseHandler.searchForCourse(courseID));
           // application.createLesson(lesson);
        }
    }

    private void refreshLessonList() {
        lessonCount = application.lessonHandler.getLessonList().size();
        ObservableList<String> lessons = FXCollections.observableArrayList(application.lessonHandler.getListOfLessonNames());
        lessons.add(0, "New Lesson");
        //Added
        lessonList.getItems().clear();
        lessonList.setItems(lessons);
    }

    public void setLesson(Lesson theLesson) {
        if (theLesson == null) {
            lesson = new Lesson();
        } else {
            lesson = theLesson;
        }
    }

    public boolean isLesson(String name) {
        String ext = "*" + name.substring(name.lastIndexOf("."));

        if (ext.equals("*.xml")) {
            return true;
        }

        return false;
    }

    @FXML
    private void newStep(ActionEvent event) {

        // create step drop region
        final Rectangle newRegion = new Rectangle(resourceWidth, resourceHeight);
        newRegion.setLayoutX(dropRegionLayoutX);
        newRegion.setLayoutY(dropRegionLayoutY + ((numberOfSteps + 2) * resourceYDistance));
        newRegion.setEffect(firstStepDropRegion.getEffect());
        newRegion.setArcHeight(firstStepDropRegion.getArcHeight());
        newRegion.setArcWidth(firstStepDropRegion.getArcWidth());
        newRegion.setFill(firstStepDropRegion.getFill());
        newRegion.setSmooth(firstStepDropRegion.smoothProperty().get());
        newRegion.setStroke(firstStepDropRegion.getStroke());
        newRegion.setStrokeDashOffset(firstStepDropRegion.getStrokeDashOffset());
        newRegion.setStrokeLineCap(firstStepDropRegion.getStrokeLineCap());
        newRegion.setId("" + (numberOfSteps + 2));

        // add the OnDragOver event handler
        newRegion.setOnDragOver(new EventHandler<DragEvent>() {
            @Override
            public void handle(DragEvent event) {
                handleOnDragOver(event);
            }
        });

        // add the OnDragEntered event handler
        newRegion.setOnDragEntered(new EventHandler<DragEvent>() {
            @Override
            public void handle(DragEvent event) {
                handleOnDragEntered(event, newRegion);
            }
        });

        // add the OnDragExited event handler
        newRegion.setOnDragExited(new EventHandler<DragEvent>() {
            @Override
            public void handle(DragEvent event) {
                handleOnDragExited(event, newRegion);
            }
        });

        // add the OnDragDropped event handler
        newRegion.setOnDragDropped(new EventHandler<DragEvent>() { // set event handler
            @Override
            public void handle(DragEvent event) {
                handleOnDragDropped(event);
            }
        });
        stepDropRegions.add(newRegion);

        // create step lable
        Label newLabel = new Label("Step " + (numberOfSteps + 1) + ":");
        newLabel.setLayoutX(firstStepLabel.getLayoutX());
        newLabel.setLayoutY(firstStepLabel.getLayoutY() + (numberOfSteps * resourceYDistance));
        newLabel.setFont(firstStepLabel.getFont());
        stepLabels.add(newLabel);

        // add widgets to gui
        lessonPane.getChildren().add(stepLabels.get(numberOfSteps - 1));
        lessonPane.getChildren().add(stepDropRegions.get(numberOfSteps - 1));

        // reposition new step button
        newStep.setLayoutY(newStep.getLayoutY() + resourceYDistance);

        // increment step count
        numberOfSteps++;

        // add empty step slot in lesson
        //lesson.addResourceBefore(null, null);

        // update content panel size and scrollbar
        double prefHight = lessonPane.getPrefHeight();
        double stepButton = newStep.getLayoutY() + newStep.getHeight();
        lessonPane.setPrefHeight(stepButton > prefHight ? stepButton + 30 : prefHight);
    }

    @FXML
    /**
     * Handle the drag detected event
     *
     * @param event the mouse event
     */
    public void handleOnDragDetected(MouseEvent event) {
        // drag was detected, start drag-and-drop gesture
        final Object obj = event.getSource();

        if (obj instanceof ImageView) { // an image resource
            // allow the copy transfer mode 
            Clipboard db = ((ImageView) obj).startDragAndDrop(TransferMode.COPY_OR_MOVE);

            // put the image and name of image on dragboard
            ClipboardContent content = new ClipboardContent();
            content.putImage(((ImageView) obj).getImage());
            content.putString(((ImageView) obj).getId());
            db.setContent(content);
        } else if (obj instanceof ListView) { // a video resource
            // allow the copy transfer mode 
            Clipboard db = ((ListView) obj).startDragAndDrop(TransferMode.COPY_OR_MOVE);

            // put the name of video on dragboard
            ClipboardContent content = new ClipboardContent();
            content.putString((String) ((ListView) obj).getSelectionModel().getSelectedItem());
            db.setContent(content);
        } else if (obj instanceof Text) {
            // allow the copy transfer mode 
            Clipboard db = ((Text) obj).startDragAndDrop(TransferMode.COPY_OR_MOVE);

            // put the name of video on dragboard
            ClipboardContent content = new ClipboardContent();
            content.putString((String) ((Text) obj).getText());
            db.setContent(content);
        }

        event.consume();
    }
    
    
    /**
     * Handle the onDragOver event
     *
     * @param event the drag event
     */
    public void handleOnDragOver(DragEvent event) {
        /* data is dragged over here */
        //System.out.println("drag over");

        if (event.getGestureSource() != event.getGestureTarget()
                && (event.getDragboard().hasImage() || event.getDragboard().hasString())) {
            event.acceptTransferModes(TransferMode.COPY_OR_MOVE);
        }

        event.consume();
    }

    /**
     * Drag-and-drop gesture entered here
     *
     * @param event
     * @param obj
     */
    public void handleOnDragEntered(DragEvent event, Object obj) {

        // show the user that it is an actual gesture target
        if (obj != event.getGestureTarget()
                && (event.getDragboard().hasImage() || event.getDragboard().hasString())) {
            if (obj instanceof Rectangle) {
                ((Rectangle) obj).setFill(Paint.valueOf("blue"));
            } else if (obj instanceof ImageView) {
                ((ImageView) obj).setOpacity(0.5);
            } else if (obj instanceof Text) {
                ((Text) obj).setFill(Color.BLUE);
            }
        }

        event.consume();
    }

    public void handleOnDragExited(DragEvent event, Object obj) {
        /* mouse moved away, remove the graphical cues */
        if (obj instanceof Rectangle) {
            ((Rectangle) obj).setFill(Paint.valueOf("transparent"));
        } else if (obj instanceof ImageView) {
            ((ImageView) obj).setOpacity(1);
        } else if (obj instanceof Text) {
            ((Text) obj).setFill(Color.BLACK);
        }

        event.consume();
    }

    /**
     * Drag dropped
     *
     * @param event the drag event
     */
    public void handleOnDragDropped(DragEvent event) {

        // if there is an image or string data on dragboard, read it and use it */
        Dragboard db = event.getDragboard();

        boolean success = false;
        if (event.getGestureTarget() instanceof Rectangle) {
            if (db.hasImage() && db.hasString()) { // image dropped

                // get the step number
                int index;
                if (event.getGestureTarget().equals(ldDropRegion)) {
                    index = 0;
                } else if (event.getGestureTarget().equals(tdDropRegion)) {
                    index = 1;
                } else if (event.getGestureTarget().equals(s1DropRegion)) {
                    index = 2;
                } else {
                    index = Integer.parseInt(((Rectangle) event.getGestureTarget()).getId());
                }

                // new picture resource dropped
                final ImageView s = new ImageView(db.getImage());
                //Image pic = new Image(resourceHeight, resourceWidth, 5, index, pictureNames.get(Integer.parseInt(db.getString())), null, null);
                s.setFitHeight(resourceHeight);
                s.setFitWidth(resourceWidth);
                s.setLayoutX(((Rectangle) event.getGestureTarget()).getLayoutX());
                s.setLayoutY(((Rectangle) event.getGestureTarget()).getLayoutY());
                s.setId(String.valueOf(index));

                s.setOnDragDetected(new EventHandler<MouseEvent>() {
                    @Override
                    public void handle(MouseEvent t) {
                        handleOnDragDetected(t);
                    }
                });
                s.setOnDragOver(new EventHandler<DragEvent>() {
                    @Override
                    public void handle(DragEvent t) {
                        handleOnDragOver(t);
                    }
                });
                s.setOnDragEntered(new EventHandler<DragEvent>() {
                    @Override
                    public void handle(DragEvent t) {
                        handleOnDragEntered(t, s);
                    }
                });
                s.setOnDragExited(new EventHandler<DragEvent>() {
                    @Override
                    public void handle(DragEvent t) {
                        handleOnDragExited(t, s);
                    }
                });
                s.setOnDragDropped(new EventHandler<DragEvent>() {
                    @Override
                    public void handle(DragEvent t) {
                        handleOnDragDropped(t);
                    }
                });

                //pic.setGuiResource(s);
                s.setId(index + "_" + (lesson.getlastResourceIndex(index) + 1));
                lessonPane.getChildren().add((ImageView) s);

                if (((Rectangle) event.getGestureTarget()).getLayoutX() > dropRegionLayoutX) {
                    //lesson.addResourceAfter(pic, lesson.lastResource(index));
                } else {
                    //lesson.addResourceBefore(pic, null);
                }
                lesson.addResource(index, new Resource(pictureNames.get(Integer.parseInt(db.getString())), Resource.ResourceType.IMAGE));

                success = true;
            } else if (db.hasString() && !db.hasImage()) {

                // get the step number
                int index;
                if (event.getGestureTarget().equals(ldDropRegion)) {
                    index = 0;
                } else if (event.getGestureTarget().equals(tdDropRegion)) {
                    index = 1;
                } else if (event.getGestureTarget().equals(s1DropRegion)) {
                    index = 2;
                } else {
                    index = Integer.parseInt(((Rectangle) event.getGestureTarget()).getId());
                }

                // new picture resource dropped
                //Video vid = new Video(10, index, db.getString(), null, null);
                final Text s = new Text();//vid.getName());
                s.setWrappingWidth(resourceWidth);
                s.setLayoutX(((Rectangle) event.getGestureTarget()).getLayoutX());
                s.setLayoutY(((Rectangle) event.getGestureTarget()).getLayoutY());


                s.setOnDragDetected(new EventHandler<MouseEvent>() {
                    @Override
                    public void handle(MouseEvent t) {
                        handleOnDragDetected(t);
                    }
                });
                s.setOnDragOver(new EventHandler<DragEvent>() {
                    @Override
                    public void handle(DragEvent t) {
                        handleOnDragOver(t);
                    }
                });
                s.setOnDragEntered(new EventHandler<DragEvent>() {
                    @Override
                    public void handle(DragEvent t) {
                        handleOnDragEntered(t, s);
                    }
                });
                s.setOnDragExited(new EventHandler<DragEvent>() {
                    @Override
                    public void handle(DragEvent t) {
                        handleOnDragExited(t, s);
                    }
                });
                s.setOnDragDropped(new EventHandler<DragEvent>() {
                    @Override
                    public void handle(DragEvent t) {
                        handleOnDragDropped(t);
                    }
                });

                //vid.setGuiResource(s);
                s.setId(index + "_" + (lesson.getlastResourceIndex(index) + 1));
                lessonPane.getChildren().add((Text) s);

                if (((Rectangle) event.getGestureTarget()).getLayoutX() > dropRegionLayoutX) {
                    //lesson.addResourceAfter(vid, lesson.lastResource(index));
                } else {
                    //lesson.addResourceBefore(vid, null);
                }
                lesson.addResource(index, new Resource(db.getString(), Resource.ResourceType.VIDEO));

                success = true;
            }
            nextResource(event);
        } else if (event.getGestureTarget() instanceof ImageView) {
            if (db.hasImage() && db.hasString()) {
                //Resource source = lesson.getResource(((ImageView) event.getGestureSource()).getId().substring(0, vidCount));
                /*if (source == null){ // a new resource being dropped
                    
                 }
                 else { // existing resource --> swap the resources
                    
                 }*/
                success = true;
            } else if (db.hasString() && !db.hasImage()) {
                //Resource source = lesson.find(event.getGestureSource());
                /*if (source == null){ // a new resource being dropped
                    
                 }
                 else { // existing resource --> swap the resources
                    
                 }*/
                success = false;
            }
        } else if (event.getGestureTarget() instanceof Text) {
        }

        // let the source know whether the string was successfully
        // transferred and used
        event.setDropCompleted(success);

        event.consume();
    }


    @FXML
    /**
     * Handle the onDragDone event
     *
     * @param event the drag event
     */
    public void handleOnDragDone(DragEvent event) {
        /* the drag-and-drop gesture ended */

        // if the data was copied successfully, finalize
        event.consume();
    }

    @FXML
    /**
     * Move widgets to make space for the next resource
     */
    private void nextResource(DragEvent event) {

        // move drop region to the right
        Rectangle dropRegion = (Rectangle) event.getSource();
        dropRegion.setLayoutX(dropRegion.getLayoutX() + resourceXDistance);

        // update content panel size and scrollbar
        double prefWidth = lessonPane.getPrefWidth();
        double region = dropRegion.getLayoutX() + dropRegion.getWidth();
        lessonPane.setPrefWidth(region > prefWidth ? region + 30 : prefWidth);

    }
    
        /**
     * Move widgets to make space for the next resource
     */
    private void nextResource(Rectangle dropRegion) {

        // move drop region to the right
        //Rectangle dropRegion = (Rectangle) event.getSource();
        dropRegion.setLayoutX(dropRegion.getLayoutX() + resourceXDistance);

        // update content panel size and scrollbar
        double prefWidth = lessonPane.getPrefWidth();
        double region = dropRegion.getLayoutX() + dropRegion.getWidth();
        lessonPane.setPrefWidth(region > prefWidth ? region + 30 : prefWidth);
    }

    /**
     * Get a list of resources from the system local directory
     */
    public void getListOfResources() {
        // get and display list of all files in the video directory
        File vidDir = new File(SCLTSL.videoDirPath);
        File[] listOfFiles = vidDir.listFiles();
        videoNames = new ArrayList<>();
        for (int i = 0; i < listOfFiles.length; i++) { // print list of files
            if (listOfFiles[i].isFile()) {
                if (isVideo(listOfFiles[i].getName())) {
                    videoNames.add(listOfFiles[i].getName());
                }
            }
        }

        // get and display list of all files in the picture directory
        File picDir = new File(SCLTSL.imageDirPath);
        listOfFiles = picDir.listFiles();
        pictureNames = new ArrayList<>();
        for (int i = 0; i < listOfFiles.length; i++) { // print list of files
            if (listOfFiles[i].isFile()) {
                if (isPicture(listOfFiles[i].getName())) {
                    pictureNames.add(listOfFiles[i].getName());
                }
            }
        }
    }


    public void refreshResourceList() {

        if (videoNames.size() > vidCount) {
            ObservableList<String> videos = FXCollections.observableArrayList(videoNames);
            videoList.setItems(videos);
            vidCount = videoNames.size();
        }

        if (pictureNames.size() > picCount) {
            picCount = pictureNames.size();
            for (int i = 1; i <= picCount; i++) {

                final ImageView newImage = new ImageView(new File(SCLTSL.imageDirPath + pictureNames.get(i - 1)).toURI().toString());
                newImage.setId(String.valueOf(i - 1));

                newImage.setFitHeight(90);
                newImage.setFitWidth(90);
                if (i % 2 == 0) {
                    newImage.setLayoutX(117);
                    newImage.setLayoutY(7 + 100 * (((int) i / 2) - 1));
                } else {
                    newImage.setLayoutX(7);
                    newImage.setLayoutY(7 + 100 * (((int) (i + 1) / 2) - 1));
                }

                // add OnDragDetected event handlers
                newImage.setOnDragDetected(new EventHandler<MouseEvent>() {
                    @Override
                    public void handle(MouseEvent event) {

                        handleOnDragDetected(event);
                    }
                });

                // add OnDragDone event handler
                newImage.setOnDragDone(new EventHandler<DragEvent>() {
                    @Override
                    public void handle(DragEvent event) {
                        handleOnDragDone(event);
                    }
                });

                picturePane.getChildren().add(newImage);

                // update horizontal scroll
                if (newImage.getLayoutY() + 90 > picturePane.getPrefHeight()) {
                    picturePane.setPrefHeight(newImage.getLayoutY() + 100);
                }
            }
        }
    }

    /**
     * create a new lesson
     */
    public void newLesson(ActionEvent event) {
        
        status.setText("NEW LESSON");
        
        // create empty lesson
        lesson = new Lesson();

       //id some how buggy
        int id = Integer.parseInt(application.lessonHandler.getBiggestLessonID()) + 1;
        String lessonID = "" + id;
        System.out.println(lessonID);
        if (id < 10) {
            lessonID = "0" + id;
        }
        lesson.setLessonID(lessonID);

        creatingLesson = true;
        lessonList.setVisible(false);
        l_title.setVisible(true);
        
        refreshLessonList();

        // update lesson
        status.setText("READY");
    }

    /**
     * Save lesson as a *.xml file
     */
    public void saveLesson() {

        try {
            if (!(l_title.getText().isEmpty() && lessonTypeList.getSelectionModel().isEmpty())) {
                lesson.setTitle(l_title.getText());
                lesson.setType(lessonTypeList.getSelectionModel().getSelectedItem().toString());
                PrintWriter writer = new PrintWriter(SCLTSL.lessonRootDirPath + lessonTypeList.getSelectionModel().getSelectedItem().toString() + "/lesson_" + lesson.getLessonID() + ".xml");
                System.out.println(l_title.getText() + ", " + lessonTypeList.getSelectionModel().getSelectedItem().toString());
                writer.println(lesson.getXML(true));
                writer.flush();

                writer.close();
                JOptionPane.showMessageDialog(null, "Lesson \"" + lesson.getTitle() + "\" Successfully Saved.");
                refreshLessonList();
            } else { // lesson title and lesson type not filled in
                //showMessagePopup("Incomplete Information", "Please make sure the lesson title and type are filled in", false, null);
            }
        } catch (Exception e) {
            System.out.println("error");
        }
        
        l_title.clear();
        lessonList.setVisible(true);
        l_title.setVisible(false);
        
        refreshLessonList();
       

    }

    /**
     * Upload multiple files to the system
     * @param event the event of the button
     */
    public void uploadFile(ActionEvent event){
        
        // update status
        status.setText("UPLOADING...");
        
        // open file chhoser to get abstract files
        FileChooser fuploadDialog = new FileChooser();
        fuploadDialog.setTitle("Upload a resource");
        fuploadDialog.getExtensionFilters().add(new FileChooser.ExtensionFilter("Video Files", videoExtensions));
        fuploadDialog.getExtensionFilters().add(new FileChooser.ExtensionFilter("Image Files", imageExtensions));
        ObservableList<String> all = FXCollections.observableArrayList(imageExtensions);
        all.addAll(videoExtensions);
        fuploadDialog.getExtensionFilters().add(new FileChooser.ExtensionFilter("All Files", all));
        List<File> uploadedFiles = fuploadDialog.showOpenMultipleDialog(null);
        
        // copy file from source to appropriate local resource directory
        try{
            if (uploadedFiles != null){
                for (File uploadedFile : uploadedFiles){
                    if (isPicture(uploadedFile.getName())) {
                        File imageListFile = new File(SCLTSL.imageDirPath + "imagelist.txt");
                        
                        if(!imageListFile.exists())
                            imageListFile.createNewFile();
                        
                        FileWriter fw = new FileWriter(imageListFile.getName(),true);
                        BufferedWriter bw = new BufferedWriter(fw);
                        
                        bw.write(uploadedFile.getName() + " |:| " + uploadedFile.getAbsolutePath());
                        bw.close();
                        //Files.copy(uploadedFile.toPath(), (new File(SCLTSL.imageDirPath + uploadedFile.getName())).toPath(), StandardCopyOption.REPLACE_EXISTING);
                        if (!pictureNames.contains(uploadedFile.getName())){
                            
                            pictureNames.add(uploadedFile.getName());
                        }
                    } else if (isVideo(uploadedFile.getName())) {       
                        File videoListFile = new File(SCLTSL.videoDirPath + "videolist.txt");
                        
                        if(!videoListFile.exists())
                            videoListFile.createNewFile();
                        
                        FileWriter fw = new FileWriter(videoListFile.getName(),true);
                        BufferedWriter bw = new BufferedWriter(fw);
                        
                        
                        //Files.copy(uploadedFile.toPath(), (new File(SCLTSL.videoDirPath + uploadedFile.getName())).toPath(), StandardCopyOption.REPLACE_EXISTING);
                        if (!videoNames.contains(uploadedFile.getName())){
                            bw.write(uploadedFile.getName() + " |:| " + uploadedFile.getAbsolutePath());
                            bw.close();
                            videoNames.add(uploadedFile.getName());
                        }
                    }
                }
                //System.out.println("copied");
                refreshResourceList();
                //showMessagePopup("Uploading Files Complete", "The files were uploaded succesfully", false, null);
                
            }
        }
        catch (Exception e){
            //System.out.println("error uploading files");
        }
        
        // update status
        status.setText("READY");
    }

    /**
     * Check if the file is a picture
     *
     * @param picName the name of the file
     * @return True if its a picture or False otherwise
     */
    private boolean isPicture(String picName) {
        String ext = "*" + picName.substring(picName.lastIndexOf("."));

        if (imageExtensions.contains(ext)) {
            return true;
        }

        return false;
    }

    /**
     * Check if the file is a video
     *
     * @param vidNamethe name of the file
     * @return True if its a video or False otherwise
     */
    private boolean isVideo(String vidName) {
        String ext = "*" + vidName.substring(vidName.lastIndexOf("."));

        if (videoExtensions.contains(ext)) {
            return true;
        }

        return false;
    }

       @FXML
    public void showMessagePopup(String title, String theMessage, boolean isDelete, File icon) {
        // Load the fxml file and create a new statge for the popup
        try {
            FXMLLoader loader = new FXMLLoader(SCLTSL.class.getResource("messagePopup.fxml"));
            AnchorPane page = (AnchorPane) loader.load();
            Stage dialogStage = new Stage();
            dialogStage.setTitle(title);
            dialogStage.initModality(Modality.WINDOW_MODAL);
            //dialogStage.initOwner(SCLTSL.primaryStage);
            Scene scene = new Scene(page);
            dialogStage.setScene(scene);

            // Set the person into the controller
            messageController = loader.getController();
            messageController.setDialogStage(dialogStage);
            messageController.setIsDelete(isDelete);
            messageController.setMessage(theMessage);

            dialogStage.setOnHidden(new EventHandler<WindowEvent>() {
                @Override
                public void handle(WindowEvent t) {
                    messageController.close();
                }
            });

            // Show the dialog and wait until the user closes it
            dialogStage.showAndWait();
            //dialogStage.
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void previewLesson() {
        // Load the fxml file and create a new statge for the popup
        try {
            FXMLLoader loader = new FXMLLoader(SCLTSL.class.getResource("previewPopup.fxml"));
            AnchorPane page = (AnchorPane) loader.load();
            Stage dialogStage = new Stage();
            dialogStage.setTitle("Play Lesson");
            dialogStage.initModality(Modality.WINDOW_MODAL);
            //dialogStage.initOwner(SCLTSL.primaryStage);
            Scene scene = new Scene(page);
            dialogStage.setScene(scene);

            // Set the person into the controller
            controller = loader.getController();
            controller.setDialogStage(dialogStage);
            controller.setLesson(lesson);

            dialogStage.setOnHidden(new EventHandler<WindowEvent>() {
                @Override
                public void handle(WindowEvent t) {
                    //throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
                    controller.close();
                }
            });

            // Show the dialog and wait until the user closes it
            dialogStage.showAndWait();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
