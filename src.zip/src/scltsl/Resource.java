/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package scltsl;

/**
 * This is the class of a Resource that is added to a lesson 
 * @version v1.1
 * @author Masilo and Muchenja
 */



public class Resource {
    
    public enum ResourceType{
        IMAGE, VIDEO;
    }
    
    /***************************************************/
    /**********************Properties*******************/
    /***************************************************/
    private final String relativeImageUrl = "/shared_images/";
    private final String relativeVideoUrl = "/video/";
    private String name;
    private ResourceType type;
    private String lessonVideoType;
    
    /*******************************************************/
    /**********************End Properties*******************/
    /*******************************************************/
    
    
    
    /***************************************************/
    /***********************Constructor*****************/
    /***************************************************/
    
    public Resource(){
    }
    
    /**
     * The constructor to create an object with specific properties
     * @param theResourceID the id of the resource
     * @param theName the name of the resource
     */
    public Resource(String theName){
        this.name = theName;
    }
    
     /**
     * The constructor to create an object with specific properties
     * @param theName the name of the resource
     * @param resType the resource type
     */
    public Resource(String theName, ResourceType resType){
        this.name = theName;
        this.type = resType;
    }
    
    /**
     * Copy constructor of the resource object
     * @param theResource the resource to make a deep copy of
     */
    public Resource(Resource theResource){
        this.name = theResource.getName();
        this.type = theResource.getType();
    }
    
    /****************************************************/
    /********************End Constructor*****************/
    /****************************************************/
    
    
    
    /****************************************************/
    /************************Methods*********************/
    /****************************************************/
    
    /**
     * Get the type of the resource
     * @return the type of the resource
     */
    public ResourceType getType(){
        return this.type;
    }

    /**
     * Set the type of the resource
     * @param type the type of the resource
     */
    public void setType(ResourceType type) {
        this.type = type;
    }
    
    public void setLessonVideoType(String lessonType){
        this.lessonVideoType = lessonType;
    }
    
    public String getLessonVideoType(){
        return this.lessonVideoType;
    }
    
    /**
     * Get the name of the resource
     * @return the name of the resource
     */
    public String getName(){
        return this.name;
    }
    
    /**
     * Set the name of the resource
     * @param theName the name of the resource
     */
    public void setName(String theName){
        this.name = theName;
    }
   
    /**
     * Get the string representation of this resource
     * @return the string representation
     */
    @Override
    public String toString(){
        return "";
    }
    
    /**
     * Get the XML representation of this resource
     * @return the XML representation
     */
    public String toXML(){
        
        String xml = "";
        
        if (this.type == ResourceType.IMAGE){
            xml = "<image>"+this.relativeImageUrl+this.getName()+"</image>";
        }
        else if (this.type == ResourceType.VIDEO){
            xml = "<video>"+this.relativeVideoUrl+this.getLessonVideoType()+"/"+this.getName()+"</video>";
        }
        
        return xml;
    } 
    
     /**
     * Get the XML representation of this resource
     * @return the XML representation
     */
    public String getLocalXML(){
        
        String xml = "";
        
        if (this.type == ResourceType.IMAGE){
            xml = "<image>"+this.getName()+"</image>";
        }
        else if (this.type == ResourceType.VIDEO){
            xml = "<video>"+this.getName()+"</video>";
        }
        
        return xml;
    } 
    
    /****************************************************/
    /********************End Methods*********************/
    /****************************************************/
}
