/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package scltsl;

import java.util.ArrayList;

/**
 *
 * @author Masilo
 */
public class Step {
    
    private int number;
    private ArrayList<Resource> resources;
    
    public Step(int step_number){
        
        this.number = step_number;
        resources = new ArrayList<>(5);
    }
    
    public int getNumber(){
        return this.number;
    }
    
    public void setNumber(int theNumber){
        this.number = theNumber;
    }
    
    public void addResourceAt(int index, Resource theResource){
        resources.add(index, theResource);
    }
    
    public void addResource(Resource theResource){
        resources.add(theResource);
    }
    
    public int getLastIndex(){
        return resources.size() - 1;
    }
    
    public int getResourceIndex(Resource theResource){
        return resources.indexOf(theResource);
    }
    
    public Resource getResource(int resourceIndex){
        return resources.get(resourceIndex);
    }
    
    public void removeResource(int resourceIndex){
        resources.remove(resourceIndex);
    }
    
    public ArrayList<Resource> getResources(){
        return resources;
    }
    
    public String toXML(){
        
        String xml = "";
        
        if (this.number == 1){ // lesson description
            xml += "\n\t<lesson_description>";
            for (int i = 0; i < resources.size(); i++){
                if (resources.get(i) == null){
                    xml += "\n\t\t<res></res>";
                }
                else {
                    xml += "\n\t\t"+resources.get(i).toXML();
                }
            }
            xml += "\n\t</lesson_description>";
        }
        else if (this.number == 2){
            xml += "\n\t\t<task_description>";
            for (int i = 0; i < resources.size(); i++){
                if (resources.get(i) == null){
                    xml += "\n\t\t\t<res></res>";
                }
                else {
                    xml += "\n\t\t\t"+resources.get(i).toXML();
                }
            }
            xml += "\n\t\t</task_description>";
        }
        else {
            xml += "\n\t\t<step_"+this.number+">";
            for (int i = 0; i < resources.size(); i++){
                if (resources.get(i) == null){
                    xml += "\n\t\t\t<res></res>";
                }
                else {
                    xml += "\n\t\t\t"+resources.get(i).toXML();
                }
            }
            xml += "\n\t\t<step_"+this.number+">";
        }
        
        return xml;
        
    }
}
